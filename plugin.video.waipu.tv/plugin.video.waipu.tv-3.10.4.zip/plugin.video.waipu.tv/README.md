
# **Waipu.tv and O2 TV Plugin for Kodi**

This is python plugin for kodi to play tv channels from waipu.tv and O2 TV.

It was initially created by [mi-ro](https://www.kodinerds.net/index.php/Thread/54288-waipu-tv-Plugin-f%C3%BCr-Kodi/?postID=474093#post474093)


# **Disclaimer**

This is an unofficial plugin. It is provided by volunteers and not related to Exaring AG or waipu.tv.
For any support regarding this plugin, please create a github issue or comment the kodinerds thread.


# **Links**

* [Waipu](https://www.waipu.tv/)
* [Support thread](https://www.kodinerds.net/index.php/Thread/64586-PreRelease-Video-Plugin-Waipu-tv/)


# **Contributors**

* [mi-ro](https://www.kodinerds.net/index.php/User/43573-mi-ro/)
* [realvito](https://www.kodinerds.net/index.php/User/20209-realvito/)
* flubshi