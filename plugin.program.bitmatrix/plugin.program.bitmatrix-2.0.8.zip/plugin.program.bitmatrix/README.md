<center>
<img src="https://github.com/tveecf/tveecf.github.io/raw/main/img/index/logo1.png" alt="drawing" width="50%"/> 

# plugin.program.bitmatrix
All in One Matrix Wizard 

BitMatrix wurde erstellt, um der Kodi-Community zu helfen und die kaputten persönlichen Wizards loszuwerden, die herumschwirren.  Da es zu Problemen führen kann, wird ein dringend Repository empfohlen, aber wenn Sie es nicht möchten, gibt es auch einen integrierten Auto-Updater.
</center>

* Backup/ Wiederherstellung bspw. persönlicher Sicherungen

* Reinigung manuell 

* Reinigung automatisch 

+ Advanced Settings Konfigurator

+ Entwicklerwerkzeuge 

+ APK Installer 

- Addon Installer 

- Fehlerbericht 

- und vielen mehr


mehr Informationen:
[wiki](https://github.com/tveecf/plugin.program.bitmatrix/wiki).