# -*- coding: utf-8 -*-
import re, requests, control, datetime, time, sys, vjackson, json, xbmcaddon, os
plupdate = False
if sys.version_info[0] == 2:
	reload(sys)
	sys.setdefaultencoding('utf-8')
addon = xbmcaddon.Addon()
signfile = os.path.join(control.dataPath,"sign.json")
chanfile = os.path.join(control.dataPath,"watched.json")
headers={'user-agent':'WATCHED/1.8.3 (android)', 'accept': 'application/json', 'content-type': 'application/json; charset=utf-8', 'cookie': 'lng='}

if addon.getSettingBool('huhu'):
	index='https://huhu.to/huhu-tv-iptv/directory.watched'
	resolver="https://huhu.to/huhu-tv-resolver/resolve.watched"
else:
	index="https://www.oha.to/oha-tv-index/directory.watched"
	resolver="https://www.oha.to/oha-tv-resolver/resolve.watched"

session = requests.session()

def getchannels(cursor=0, channels=[], sort= "name", groups=["Germany"]):
	for group in groups:
		data={"adult": True,"cursor": cursor,"filter": {"group": group},"sort": sort}
		headers.update({'watched-sig': vjackson.getAuthSignature()})
		r = requests.post(index, data=json.dumps(data), headers=headers).json()
		channels+=r["items"]
		nextCursor = r.get("nextCursor", False)
		if nextCursor:
			getchannels(nextCursor, channels)
	return channels

def main():
	if os.path.exists(chanfile):
		with open(chanfile, "r") as k:
			r = json.load(k)
			if r.get('sigValidUntil', 0) > int(time.time()) and r.get('resolver') == resolver:
				return r.get('channels')
	groups = {}
	channels=getchannels()
	for p in getchannels(cursor=0, channels=[], sort= "name", groups=["Balkans"]):
		if "DE :" in p["name"]:
			channels.append({'type': 'iptv', 'ids': {}, 'url':p["url"], 'name':p["name"], 'group': 'Balkans', 'logo':p["logo"]})
	for c in channels:
		name = re.sub("\(.*\)", "", c["name"])
		name = name.replace('EINS', '1').replace('ZWEI', '2').replace('DREI', '3').replace('SIEBEN', '7').replace('DE : ', '').replace(' |C', '').replace(' |E', '').replace(' FHD', '').replace(' HD', '').replace(' 1080', '').replace(' AUSTRIA', '').replace(' GERMANY', '').replace(' DEUTSCHLAND', '').replace(' |D', '').replace('HEVC', '').replace('RAW', '').strip()
		if "1-2-3" in name: name = "arriba"
		name = name.replace('KRIME', 'KRIMI').replace('SPORT BUNDESLIGA', 'BUNDESLIGA').replace('PRO7', 'PRO 7').replace('.', '').replace('ACITON', 'ACTION').replace('SERIES', 'SERIE').replace(' SD', '').replace('  YOU', '').replace('SKY DISNEY', 'DISNEY').replace('SKY NAT', 'NAT').replace('SKY POP', 'POP').replace('SKY UNI', 'UNI').replace('SKY CINEMA 24', 'SKY CINEMA +24').replace('SKY CINEMA 1', 'SKY CINEMA +1').replace('NAT GEOGRAPHIC', 'NATIONAL GEOGRAPHIC').replace('  ', ' ')
		if "HEIMA" in name: name = "HEIMATKANAL"
		if "CENTRAL" in name or "VIVA" in name: name = "VIVA"
		if "BR" and "FERNSEHEN" in name: name = "BR"
		if "DMAX" in name: name = "DMAX"
		if "KINOWELT" in name: name = "KINOWELT"
		if "MDR" in name: name = "MDR"
		if "RBB" in name: name = "RBB"
		if "RTL+" in name: name = "RTL UP"
		if "WDR" in name: name = "WDR"
		if "PLANET" in name: name = "PLANET"
		if "NITRO" in name: name = "RTL NITRO"
		if "SYFY" in name: name = "SYFY"
		if "E!" in name: name = "E! ENTERTAINMENT"
		if "ENTERTAINMENT" in name: name = "E! ENTERTAINMENT"
		if "STREET" in name: name = "13TH STREET"
		if "WUNDER" in name: name = "WELT DER WUNDER"
		if "KAB" and "CLA" in name: name = "KABEL 1 CLASSICS"
		if "MAXX" in name: name = "PRO 7 MAXX"
		if "PRO" and "FUN" in name: name = "PRO 7 FUN"
		if "ZEE" in name: name = "ZEE ONE"
		if "FOX" in name: name = "FOX"
		if "AXN" in name: name = "AXN"
		if "arriba" in name: name = "1-2-3 TV"
		if "UNIVERSAL" in name: name = "UNIVERSAL"
		if "DELUX" in name: name = "DELUXE MUSIC"
		if "DISCO" in name: name = "DISCOVERY"
		if "TLC" in name: name = "TLC"
		if "HISTORY" in name: name = "HISTORY"
		if "ATLANTIC" in name: name = "SKY ATLANTIC"
		if "WILD" in name: name = "NAT GEO WILD"
		if "VISION" in name: name = "MOTORVISION"
		if "INVESTIGATION" in name or "A&E" in name: name = "A&E"
		if "AUTO" in name: name = "AUTO MOTOR SPORT"
		if "GEOGRAPHIC" in name: name = "NAT GEO"
		if "TNT FILM" in name: name = "WARNER TV FILM"
		if "TNT SERIE" in name: name = "WARNER TV SERIE"
		if "TNT COMEDY" in name: name = "WARNER TV COMEDY"
		if name not in groups:
			groups[name] = []
		groups[name].append(c['url'])
	data={"resolver":resolver, "sigValidUntil": int(time.time()) + 300, "channels": groups}
	with open(chanfile, "w") as write_file:
		json.dump(data, write_file, indent=4, sort_keys=True)
	return groups
	
def choose():
	url="https://www.oha.to/oha-tv-index/directory.watched"
	#url='https://huhu.to/huhu-tv-iptv/directory.watched'
	headers={'user-agent':'WATCHED/1.8.3 (android)', 'accept-encoding': 'gzip', 'content-type': 'application/json; charset=utf-8', 'watched-sig': vjackson.getAuthSignature()}
	data={"adult": True,"filter": {},"id": "","language": "de","region": "AT","rootId": "","search": "","sort": "name"}
	r = session.post(url, data=json.dumps(data), headers=headers).json()
	new_groups = r["features"].get("filter")[0]["values"]
	indicies = control.selectDialog(new_groups, "Choose Groups", True)
	group = []
	if indicies:
		for i in indicies:
			group.append(new_groups[i])
	if len(group) > 0:
		control.setcache( "plugin.video.vavooto.gruppen", group)
		main(new=True)
		icies = control.selectDialog(new_groups, "Choose Groups", True)
	group = []
	if indicies:
		for i in indicies:
			group.append(new_groups[i])
	if len(group) > 0:
		control.setcache( "plugin.video.vavooto.gruppen", group)
		main(new=True)
		