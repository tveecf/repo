# -*- coding: utf-8 -*-
import kanal, control
plupdate = False

def playup():
	global plupdate
	if plupdate:
		return
	if not control.getcache("plugin.video.vavooto.gruppen"):
		return
	plupdate = True
	kanal.main()
	plupdate = False
		
if __name__ == '__main__':
	while not control.abortRequested():
		if control.getSettingBool('playauto'):
			if control.waitForAbort(5):
				break
			playup()