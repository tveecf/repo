# -*- coding: utf-8 -*-
import random, base64, requests, xbmcplugin, sys, xbmcgui
PY2 = sys.version_info[0] < 3
if PY2:
	from urllib2 import HTTPError
	from urllib import quote_plus, urlencode
	from urlparse import parse_qs, urlparse, urljoin
	from xbmc import translatePath as kodipath
else:
	from urllib.parse import quote_plus, urlencode, parse_qs, urlparse, urljoin
	from urllib.error import HTTPError
	from xbmcvfs import translatePath as kodipath
base_link = 'http://www.youtube.com'
key_link = random.choice(['QUl6YVN5RDd2aFpDLTYta2habTVuYlVyLTZ0Q0JRQnZWcnFkeHNz', 'QUl6YVN5Q2RiNEFNenZpVG0yaHJhSFY3MXo2Nl9HNXBhM2ZvVXd3'])
key_link = '&key=%s' % base64.urlsafe_b64decode(key_link)
search_link = 'https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&maxResults=5&q=%s'
youtube_search = 'https://www.googleapis.com/youtube/v3/search?q='
youtube_watch = 'http://www.youtube.com/watch?v=%s'

def play(name, url=None, language='de'):
    if url:
        if url.startswith(base_link):
            url = _resolve(url)
        elif not url.startswith('http://'):
            url = _resolve(youtube_watch % url)
    if not url:
        url = _search(youtube_search + name + ' Trailer Deutsch', language)
    if url:
        o = xbmcgui.ListItem()
        o.setPath(url)
        o.setProperty('IsPlayable', 'true')
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, o)


def _search(url, language):
    query = parse_qs(urlparse(url).query)['q'][0]
    url += '&relevanceLanguage=%s' % language
    url = search_link % quote_plus(query) + key_link
    items = requests.get(url).json()['items']
    items = [ i['id']['videoId'] for i in items ]
    for url in items:
        url = _resolve(url)
        if url:
            return url


def _resolve(url):
    id = url.split('?v=')[(-1)].split('/')[(-1)].split('?')[0].split('&')[0]
    return 'plugin://plugin.video.youtube/play/?video_id=%s' % id