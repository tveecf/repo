# -*- coding: utf-8 -*-
import os, io, sys, time
PY2 = sys.version_info[0] == 2
PY3 = sys.version_info[0] == 3
if PY2:
	from urllib import urlencode
else:
	from urllib.parse import urlencode
try:
	import xbmc, xbmcplugin, xbmcgui, xbmcaddon, xbmcvfs, simplecache
	runinKodi = True
except:
	runinKodi = False
def getKodiVersion():
	return int(xbmc.getInfoLabel("System.BuildVersion")[:2])

addon = xbmcaddon.Addon() if runinKodi else None
addonId = xbmcaddon.Addon().getAddonInfo('id') if runinKodi else None
addonInfo = xbmcaddon.Addon().getAddonInfo if runinKodi else None
addonName = addonInfo('name') if runinKodi else None
addonVersion = addonInfo('version')  if runinKodi else None
addonIcon = addonInfo('icon') if runinKodi else None
item = xbmcgui.ListItem if runinKodi else None
labelControl = xbmcgui.ControlLabel if runinKodi else None
homeWindow = xbmcgui.Window(10000) if runinKodi else None
windowDialog = xbmcgui.WindowDialog() if runinKodi else None
dialog = xbmcgui.Dialog() if runinKodi else None
progressDialog = xbmcgui.DialogProgress() if runinKodi else None
progressDialogBG = xbmcgui.DialogProgressBG() if runinKodi else None
addItem = xbmcplugin.addDirectoryItem if runinKodi else None
directory = xbmcplugin.endOfDirectory if runinKodi else None
resolve = xbmcplugin.setResolvedUrl if runinKodi else None
condVisibility = xbmc.getCondVisibility if runinKodi else None
execute = xbmc.executebuiltin if runinKodi else None
infoLabel = xbmc.getInfoLabel if runinKodi else None
keyboard = xbmc.Keyboard if runinKodi else None
monitor = xbmc.Monitor() if runinKodi else None
jsonrpc = xbmc.executeJSONRPC if runinKodi else None
abortRequested = monitor.abortRequested if runinKodi else None
waitForAbort = monitor.waitForAbort if runinKodi else None
cache = simplecache.SimpleCache() if runinKodi else None
setcache = cache.set if runinKodi else None
getcache = cache.get if runinKodi else None
setResolvedUrl = xbmcplugin.setResolvedUrl if runinKodi else None
setContent = xbmcplugin.setContent if runinKodi else None
addSortMethod = xbmcplugin.addSortMethod if runinKodi else None
SORT_METHOD_LABEL =xbmcplugin.SORT_METHOD_LABEL if runinKodi else None
try:
	handle = int(sys.argv[1])
except:
	handle = None
 
def getSetting(settingid, id=None):
	if id == None:
		id = xbmcaddon.Addon().getAddonInfo('id')
	return xbmcaddon.Addon(id).getSetting(settingid)
	
def getSettingBool(settingid, id=None):
	if id == None:
		id = xbmcaddon.Addon().getAddonInfo('id')
	if getSetting(settingid, id) == 'true':
		return True
	return False
	
def getSettingInt(settingid, id=None):
	if id == None:
		id = xbmcaddon.Addon().getAddonInfo('id')
	return int(getSetting(settingid, id))
	
def setSetting(settingid, value, id=None):
	if id == None:
		id = xbmcaddon.Addon().getAddonInfo('id')
	xbmcaddon.Addon(id).setSetting(settingid, value)
	
def openSetting(id=None):
	if id == None:
		id = xbmcaddon.Addon().getAddonInfo('id')
	try:
		xbmcaddon.Addon(id).openSettings()
	except:
		return

def transPath(path):
	if runinKodi:
		if getKodiVersion() < 19:
			return xbmc.translatePath(path).decode('utf-8')
		return xbmcvfs.translatePath(path)
	return path

def isfile(file):
	if os.path.isfile(transPath(file)):
		return True
	return False

def exists(fileorfolder):
	if os.path.isfile(transPath(fileorfolder)) or os.path.isdir(transPath(fileorfolder)):
		return True
	return False

def delete(fileorfolder, onlyfiles=False):
	if exists(fileorfolder):
		if isfile(transPath(fileorfolder)):
			os.remove(transPath(fileorfolder))
		elif onlyfiles:
			for root, dirs, files in os.walk(transPath(fileorfolder)):
				for name in files:
					os.remove(os.path.join(root, name))
		else:
			shutil.rmtree(transPath(fileorfolder),ignore_errors=True)
			
def joinPath(path, newpath):
	return os.path.join(transPath(path), newpath)
	
listDir = xbmcvfs.listdir if runinKodi else os.listdir
mkdir = xbmcvfs.mkdir if runinKodi else os.mkdir
mkdirs = xbmcvfs.mkdirs if runinKodi else os.makedirs
open = xbmcvfs.File if runinKodi else io.open 
rename = xbmcvfs.rename if runinKodi else os.rename

def legalFilename(name):
	if getKodiVersion() < 19:
		return xbmc.makeLegalFilename(name)
	else:
		return xbmcvfs.makeLegalFilename(name)
		
dataPath = transPath(addonInfo('profile')) if runinKodi else None
	
SETTINGS_PATH = transPath(os.path.join(addonInfo('path'), 'resources', 'settings.xml')) if runinKodi else None

settingsFile = os.path.join(dataPath, 'settings.xml') if runinKodi else None

def sleep(time):  # Modified `sleep`(in milli secs) command that honors a user exit request
	while time > 0 and not monitor.abortRequested():
		xbmc.sleep(min(100, time))
		time = time - 100

def addonVersion(addon):
	return xbmcaddon.Addon(addon).getAddonInfo('version')

def addonId():
	return addonInfo('id')

def convertPluginParams(queries):
	try:
		query = urlencode(queries)
	except UnicodeEncodeError:
		for k in queries:
			if isinstance(queries[k], unicode):
				queries[k] = queries[k].encode('utf-8')
		query = urlencode(queries)
	return query

def getPluginUrl(params):
	addon_id = sys.argv[0]
	if not addon_id:
		addon_id = addonId()
	return addon_id + '?' + convertPluginParams(params)

def addonName():
	return addonInfo('name')	

def addonPath(addon):
	try: addonID = xbmcaddon.Addon(addon)
	except: addonID = None
	if addonID is None: return ''
	else:
		return transPath(addonID.getAddonInfo('path'))

def selectDialog(list, heading=None, multiselect = False):
	if heading == 'default' or heading is None:
		heading = addonInfo('name')
	if multiselect:
		return dialog.multiselect(str(heading), list)
	return dialog.select(str(heading), list)
	
def okDialog(title=None, message=None):
	if title == 'default' or title is None:
		title = addonName()
	if isinstance(title, (int, float)):
		heading = lang(title)
	else:
		heading = str(title)
	if isinstance(message, (int, float)):
		body = lang(message)
	else:
		body = str(message)
	return dialog.ok(heading, body)
	
def notification(title=None, message=None, icon=None, time=3000, sound=None):
	if sound == None:
		sound=(setting('notification.sound') == 'true')
	if title == 'default' or title is None:
		title = addonName()
	if isinstance(title, (int, float)):
		heading = lang(title)
	else:
		heading = str(title)
	if isinstance(message, (int, float)):
		body = lang(message)
	else:
		body = str(message)
	if icon is None or icon == '' or icon == 'default':
		icon = addonIcon()
	elif icon == 'INFO':
		icon = xbmcgui.NOTIFICATION_INFO
	elif icon == 'WARNING':
		icon = xbmcgui.NOTIFICATION_WARNING
	elif icon == 'ERROR':
		icon = xbmcgui.NOTIFICATION_ERROR
	dialog.notification(heading, body, icon, time, sound=sound)

def yesnoDialog(line1, line2='', line3='', heading=None, nolabel='', yeslabel=''):
	if heading == 'default' or heading is None:
		heading = addonInfo('name')
	if PY3:return dialog.yesno(heading, line1+"\n"+line2+"\n"+line3, nolabel, yeslabel)
	else:return dialog.yesno(heading, line1,line2,line3, nolabel, yeslabel)