# -*- coding: utf-8 -*-
import xbmcaddon, xbmcplugin, xbmcgui, sys, xbmc, os, json, re, time, requests, urllib3, utils
from xbmcplugin import addDirectoryItem as add
from xbmcgui import ListItem
urllib3.disable_warnings()
session = requests.session()
from base64 import b64encode, b64decode 
BASEURL = 'https://www2.vjackson.info/ccapi/'
MAX_SEARCH_HISTORY_ITEMS = 20

def end(succeeded=True, cacheToDisc=True):
	return xbmcplugin.endOfDirectory(utils.handle(), succeeded=succeeded, cacheToDisc=cacheToDisc)

def action_index(params):
	xbmcplugin.setContent(utils.handle(), 'files')
	addDir2("Live", "pvr", "channels")
	addDir2('Filme', 'movies', 'indexMovie')
	addDir2('Serien', 'series', 'indexSerie')
	addDir2('Suche', 'search', 'search', id='all.popular')
	addDir2('Einstellungen', 'settings', 'settings')
	end()

def indexMovie(params):
	xbmcplugin.setContent(utils.handle(), 'movies')
	addDir2('Beliebte Filme', 'movies', 'action_list', id='movie.popular')
	addDir2('Angesagte Filme', 'movies', 'action_list', id='movie.trending')
	addDir2('Genres', 'genres', 'genres', id='movie.popular')
	addDir2('Suche', 'search', 'search', id='movie.popular')
	addDir2('Einstellungen', 'settings', 'settings')
	end()

def indexSerie(params):
	xbmcplugin.setContent(utils.handle(), 'tvshows')
	addDir2('Beliebte Serien', 'series', 'action_list', id='series.popular')
	addDir2('Angesagte Serien', 'series', 'action_list', id='series.trending')
	addDir2('Genres', 'genres', 'genres', id='series.popular')
	addDir2('Suche', 'search', 'search', id='series.popular')
	addDir2('Einstellungen', 'settings', 'settings')
	end()

STREAM_SELECT_OPTIONS = ('hosters2', 'auto', 'grouped')
LANGUAGE_NAMES = {'de': {'de': 'Deutsch', 'en': 'Englisch'}, 'en': {'de': 'German', 'en': 'English'}}

def getStreamSelect():
	return STREAM_SELECT_OPTIONS[int(utils.addon.getSetting('stream_select') or 0)]

def getAutoTryNextStream():
	return utils.addon.getSetting('auto_try_next_stream') != 'false'

def prepareListItem(params, e, isPlayable=False, callback=None):
	infos = {}
	properties = {}

	def getMeta(*paths, **kwargs):
		for path in paths:
			f = e
			for p in path:
				try:
					f = f[p]
				except (KeyError, TypeError):
					f = None
					break
			if f:
				return f
		return kwargs.get('default', None)

	def setInfo(key, value):
		if value:
			if type(value) is list:
				infos[key] = (', ').join(value)
			else:
				infos[key] = value

	def setProperty(key, value):
		if value:
			properties[key] = value

	def setInfoPeople(key, value):
		if value:
			setInfo(key, value)

	title = e['name']
	attrs = []
	if attrs:
		title += ' (' + (', ').join(attrs) + ')'
	if 'channelName' in e:
		title = '[B]' + e['channelName'] + '[/B]: ' + title
	setInfo('title', title)
	setInfo('originaltitle', e['originalName'])
	setInfo('year', getMeta(('year', )))
	art = {'thumb': getMeta(('poster', ), default='DefaultVideo.png'), 'poster': getMeta(('poster', ), default='DefaultVideo.png'), 'banner': getMeta(('backdrop', ))}

	def updateInfos(data):
		setInfo('plot', data.get('description'))
		setInfo('code', data.get('id'))
		setInfo('premiered', data.get('releaseDate'))
	updateInfos(e)
	if not isMovie(e) and 'season' in params and 'current_episode' in e:
		ep = e['current_episode']
		season = params['season']
		episode = ep['episode']
		if season == 0:
			setInfo('TVShowTitle', 'Extras, Episode %s' % episode)
		else:
			setInfo('TVShowTitle', 'Season %s Episode %s' % (season, episode))
		setInfo('season', season)
		setInfo('episode', episode)
		episode_title = ep.get('name', None)
		if episode_title and not episode_title.startswith('Episode '):
			setInfo('TVShowTitle', episode_title)
		updateInfos(ep)
	genres = set()
	for g in getMeta(('genres', )) or tuple():
		genres.add(g)
	genres = (', ').join(sorted(genres))
	setInfo('genre', genres)
	countries = set()
	for g in getMeta(('countries', )) or tuple():
		countries.add(g)
	countries = (', ').join(sorted(countries))
	setInfo('country', countries)
	setInfoPeople('cast', getMeta(('cast', )))
	setInfo('director', getMeta(('director', )))
	setInfo('writer', getMeta(('writer', )))
	setProperty('selectaction', 'info')
	if isPlayable:
		setProperty('IsPlayable', 'true')
	contextMenuItems = []
	#import dldb2
	#dldb2.createListItemHook(params, e, isPlayable, properties, contextMenuItems)
	if callback:
		callback(params, e, isPlayable, properties, contextMenuItems)
	return (infos, properties, art, contextMenuItems)

def isMovie(e):
	return e['id'].startswith('movie')

def createListItem(params, e, isPlayable=False, o=None, **kwargs):
	infos, properties, art, contextMenuItems = prepareListItem(params, e, isPlayable=isPlayable, **kwargs)
	if o is None:
		o = ListItem()
	o.setInfo('Video', infos)
	o.setLabel(infos['title'])
	o.addContextMenuItems(contextMenuItems, False)
	for key, value in list(properties.items()):
		if not isinstance(value, str):
			value = str(value)
		o.setProperty(key, value)
	if art:
		o.setArt(art)
		if art['thumb']:
			o.setArt({"thumb":art["thumb"]})
	return o

def action_list(params):
	data = cachedcall('list', {'id': params['id']})
	if params['id'].startswith('movie'):
		content = 'movies'
	else:
		content = 'tvshows'
	xbmcplugin.setContent(utils.handle(), content)
	items = []
	for i, e in enumerate(data['data']):
		if isMovie(e):
			isPlayable = True
			isFolder = False
			action = 'action_get'
		else:
			isPlayable = False
			isFolder = True
			action = 'action_seasons'
		urlParams = {'action': action, 'id': str(e['id'])}
		o = createListItem(urlParams, e, isPlayable=isPlayable)
		items.append((i, urlParams, o, isFolder))
	for _, urlParams, o, isFolder in sorted(items):
		add(handle=utils.handle(), url=utils.getPluginUrl(urlParams), listitem=o, isFolder=isFolder)
	if data['next']:
		addDir('>>> Weiter', utils.getPluginUrl({'action': 'action_list', 'id': data['next']}))
	end()
	
def search(params):
	query = None
	if params.get('query'):
		query = params.get('query')
	else:
		heading='VAVOO.TO - SUCHE'
		if 'movie' in params['id']:
			heading='VAVOO.TO - FILM SUCHE'
		if 'serie' in params['id']:
			heading='VAVOO.TO - SERIEN SUCHE'
		kb = xbmc.Keyboard('', heading, False)
		kb.doModal()
		if (kb.isConfirmed()):
			query = kb.getText()
	if query:
		params['id'] = '%s.search=%s' % (params['id'], query.replace('.', '%2E'))
		action_list(params)
	return

def genres(params):
	genrelist=['Action', 'Abenteuer', 'Animation', 'Komödie', 'Krimi', 'Dokumentarfilm', 'Drama', 'Familie', 'Fantasy', 'Historie', 'Horror', 'Musik', 'Mystery', 'Liebesfilm', 'Science Fiction', 'TV-Film', 'Thriller', 'Kriegsfilm', 'Western']
	if 'serie' in params['id']:
		genrelist= ['Action & Adventure', 'Animation', 'Komödie', 'Krimi', 'Dokumentarfilm', 'Drama', 'Familie', 'Kids', 'Mystery', 'News', 'Reality', 'Sci-Fi & Fantasy', 'Soap', 'Talk', 'War & Politics', 'Western']
	for genre in genrelist:
		addDir2(genre, 'genres', 'action_list', id='%s.genre=%s' % (params['id'], genre))
	end()

def action_seasons(params):
	params['language'] = 'de'
	data = cachedcall('info', params)
	seasons = list(sorted(map(int, list(data['seasons'].keys()))))
	if len(seasons) == 1:
		params['season'] = seasons[0]
		action_episodes(params)
	xbmcplugin.setContent(utils.handle(), 'seasons')
	params['action'] = 'action_episodes'
	for i in seasons:
		params['season'] = str(i)
		o = createListItem(params, data)
		if i == 0:
			o.setLabel('Extras')
		else:
			o.setLabel('Season ' + str(i))
		add(handle=utils.handle(), url=utils.getPluginUrl(params), listitem=o, isFolder=True)
	end()

def action_episodes(params):
	if 'language' not in params:
		params['language'] = 'de'
	xbmcplugin.setContent(utils.handle(), 'episodes')
	data = cachedcall('info', params)
	season = str(params['season'])
	params = {'action': 'action_get'}
	for i in data['seasons'][season]:
		params['id'] = '%s.%s.%s' % (data['id'], season, i['episode'])
		data['current_episode'] = i
		o = createListItem(params, data, isPlayable=True)
		o.setLabel('Season ' + season + ' Episode ' + str(i['episode']))
		add(handle=utils.handle(), url=utils.getPluginUrl(params), listitem=o, isFolder=False)
	end()

class Player(xbmc.Player):
	pass

class action_get(object):

	def __init__(self, params):
		self.params = params
		self.selectedParts = {}
		self.mirrorsTried = 0
		self.line1 = ""
		self.line2 = ""
		self.line3 = ""
		try:
			self.run()
		except Exception:
			import traceback
			utils.log(traceback.format_exc())
			raise
		return
	
	def getStreamSelect(self):
		return getStreamSelect()

	def init(self):
		self.player = Player()
		self.player.stop()
		if not self.params.get('language'):
			self.params['language'] = 'de'
		if self.params.get('trailer'):
			self.data = cachedcall('info', self.params)
			self.mirrors = self.data.get('videos')
			if not self.mirrors:
				raise ValueError('keine trailer gefunden')
			return False
		#import dldb2
		#if dldb2.downloadGet(self.params):
			#return True
		self.data = cachedcall('info', self.params)
		self.mirrors = cachedcall('links', self.params)
		if not self.mirrors:
			raise ValueError('keine mirrors gefunden')
		return False

	def run(self):
		if self.init():
			return
		else:
			SUPERWEIGHTS = {'clipboard.cc': 5, 'kinoger.com': 4, 'openload.co': 3, 'streamango.com': 2, 'streamcloud.eu': 1}
			self.groups = []
			groupsByLanguage = {}
			for i, mirror in enumerate(self.mirrors):
				if 'hoster' not in mirror:
					mirror['hoster'] = utils.urlparse(mirror['url']).netloc
				mirror['caption'] = mirror['hoster']
				mirror['weight'] = SUPERWEIGHTS.get(mirror['hoster'], 0) 
				#utils.log('WEIGHT = %s /// %s %s /// %s' % (mirror['weight'],SUPERWEIGHTS.get(mirror['hoster'], 0),weights.get(mirror['hoster'], 0),mirror['hoster']))
				mirror['language'] = mirror.get('language', mirror.get('languages', ['??'])[0])
				if mirror['language'] not in groupsByLanguage:
					attrs = []
					attrs.append(LANGUAGE_NAMES["de"].get(mirror['language'], mirror['language']))
					group = {'caption': (', ').join(attrs), 'mirrors': []}
					group['priority'] = i
					self.groups.append(group)
					groupsByLanguage[mirror['language']] = group
				groupsByLanguage[mirror['language']]['mirrors'].append(mirror)
			self.mirrors = []
			self.groups = list(sorted(self.groups, key=lambda x: x['priority']))
			for group in self.groups:
				n = len(group['mirrors'])
				group['caption'] += ' (%s Mirrors)' % n
				group['mirrors'] = list(sorted(group['mirrors'], key=lambda m: -m['weight']))
				self.mirrors.extend(group['mirrors'])
			self.streamSelect = self.getStreamSelect()
			if self.streamSelect == 'grouped':
				heading = 'Sprache wählen'
				captions = [ mirror['caption'] for mirror in self.groups ]
			elif self.streamSelect == 'hosters':
				heading = 'Hoster wählen'
				captions = [ mirror['caption'] for mirror in self.mirrors ]
			elif self.streamSelect == 'hosters2':
				heading = 'Hoster wählen'
				captions = []
				for i, mirror in enumerate(self.mirrors):
					mirror['caption'] = 'Mirror %s, %s' % (i + 1, mirror.get('name', mirror['hoster']))
					#mirror['short_caption'] = 'Mirror %s, %s' % (i + 1, mirror.get('name', mirror['hoster']))
					captions.append(mirror['caption'])
			elif self.streamSelect != 'auto':
				raise RuntimeError('Invalid value for streamSelect: %s' % self.streamSelect)
			if self.streamSelect != 'auto':
				index = xbmcgui.Dialog().select(heading, captions)
				if index < 0:
					return
			else:
				index = 0
			if self.streamSelect == 'grouped':
				self.mirrors = self.groups[index]['mirrors']
			elif self.streamSelect == 'hosters':
				mirror = self.mirrors[index]
				group = groupsByLanguage[mirror['language']]
				self.mirrors = group['mirrors'][group['mirrors'].index(mirror):]
			elif self.streamSelect == 'hosters2':
				self.mirrors = self.mirrors[index:]
			if self.streamSelect in ('hosters', 'hosters2') and not getAutoTryNextStream():
				self.mirrors = [self.mirrors[0]]
			#from urlresolver import load_external_plugins
			#from urlresolver.resolver import ResolverError
			#load_external_plugins()
			self.initProgress()
			try:
				try:
					self.findMirror()
				except ValueError as e:
					if str(e) == 'CANCELED':
						return
					if str(e) == 'FAILED':
						self.showFailedNotification()
						return
					raise
			finally:
				if self.progress is not None:
					self.progress.close()
					self.progress = None
			return

	def showFailedNotification(self):
		xbmc.executebuiltin('Notification(%s,%s,%s,%s)' % (
		 'VAVOO.TO',
		 'Beim aufrufen des Streams ist ein Fehler aufgetreten',
		 5000,
		 utils.addon.getutils.addonInfo('icon')))

	def initProgress(self):
		self.progress = xbmcgui.DialogProgress()
		self.progress.create('VAVOO.TO', 'Der Stream wird gestartet...')

	def checkCanceled(self):
		if self.progress.iscanceled():
			raise ValueError('CANCELED')

	def setMirrorProgress(self, step):
		STEPS_PER_MIRROR = 4
		current = step
		total = STEPS_PER_MIRROR
		if self.progress is None:
			self.initProgress()
		if utils.PY2:
			self.progress.update(int(current * (100.0 / total)), self.line1, self.line2, self.line3)
		else:
			self.progress.update(int(current * (100.0 / total)), self.line1+"\n"+self.line2+"\n"+self.line3)
		self.checkCanceled()

	def findMirror(self):
		prevMirror = None
		for self.mirrorIndex, mirror in enumerate(self.mirrors):
			if self.mirrorIndex == 0:
				self.line1 = 'Die Wiedergabe wird gestartet.'
				self.line2 = mirror.get('caption')
			else:
				self.line1 = '%s fehlgeschlagen.' % prevMirror
				self.line2 = 'Versuche %s...' % mirror.get('caption')
			self.setMirrorProgress(0)
			prevMirror = mirror.get('caption')
			self.checkCanceled()
			url = mirror['url']
			if url is None:
				continue
			url = url.replace('https://nullrefer.com/?', '')
			resolvedUrl = self.resolveUrl(mirror, url)
			if not resolvedUrl:
				continue
			self.setMirrorProgress(1)
			if self.tryMirror(mirror, url, resolvedUrl):
				return
		raise ValueError('FAILED')
		return

	def resolveUrl(self, mirror, url):
		utils.log('Resolving URL: %s' % url)
		cacheKey = url
		originalUrl = url
		cachedUrl = utils.get_cache(cacheKey)
		if cachedUrl:
			utils.log('Got resolved URL from cache: %s' % cachedUrl)
			return cachedUrl
		else:
			url = self.resolveUrl1(mirror, originalUrl)
			utils.log('Resolve 1: %s' % url)
			if url:
				utils.set_cache(cacheKey, url)
				return url
			if url is False:
				utils.log('Reporting not working URL: %s' % url)
			return

	def unshorten(self, url):
		from contextlib import closing
		with closing(session.head(url, verify=False)) as req:
			r = req
		if not r.headers.get('location'):  # not a redirect
			return url
		tmp_url = url
		try:
			for redir in session.resolve_redirects(r, r.request, verify=False):
				if redir.status_code == 200: #and not url_no_good(redir.url):  # ok!
					return redir.url
				else:
					tmp_url = redir.url
			else: # no acceptable responses :(
				return tmp_url
		except requests.exceptions.TooManyRedirects:
			return url

	def resolveUrl1(self, mirror, url):
		params = {'link': url}
		res = cachedcall('open', params)
		url = res[len(res)-1]['url']
		return self.unshorten(url)

	def tryMirror(self, mirror, url, resolvedUrl):
		utils.log('Trying resolved URL: %s' % resolvedUrl)
		try:
			#resolvedUrl = fix_stream_url(resolvedUrl)
			o = createListItem(self.params, self.data, isPlayable=True)
			o.setPath(resolvedUrl)
			self.player.play(resolvedUrl, o)
			self.mirrorsTried += 1

			def infostr():
				try:
					return 'step=%s, playing=%s, time=%s URL: %s' % (
					 step, self.player.isPlaying(),
					 self.player.isPlaying() and self.player.getTime(),
					 mirror['hoster'])
				except RuntimeError as e:
					if str(e) == 'XBMC is not playing any media file':
						return 'XBMC is not playing any media file'
					raise
			step = 1
			STEP_TIMEOUT = 45
			abortReason = ''
			t = time.time()
			try:
				sleep = 10
				while not abortReason:
					utils.log('Player running: %s' % infostr())
					if xbmc.Monitor().abortRequested() or self.progress and self.progress.iscanceled():
						abortReason = 'canceled'
					elif step == 1:
						if self.player.isPlaying():
							self.setMirrorProgress(2)
							step = 2
						elif time.time() - t > STEP_TIMEOUT:
							abortReason = 'timeout'
					elif step == 2:
						if xbmc.getInfoLabel('VideoPlayer.VideoResolution'):
							self.line3='Viel Spaß mit VAVOO!'
							self.setMirrorProgress(3)
							self.player.stop()
							sleep = 100
							step = 3
						elif not self.player.isPlaying():
							abortReason = 'died'
					elif step == 3:
						if not self.player.isPlaying():
							xbmcplugin.setResolvedUrl(utils.handle(), True, o)
							t = time.time()
							step = 4
					elif step == 4:
						if self.player.isPlaying():
							self.setMirrorProgress(4)
							step = 5
						elif time.time() - t > STEP_TIMEOUT:
							abortReason = 'timeout'
					elif step == 5:
						if not self.player.isPlaying():
							abortReason = 'stopped'
						elif self.player.getTime() > 0.0:
							resolution = xbmc.getInfoLabel('VideoPlayer.VideoResolution')
							if resolution:
								if self.progress is not None:
									self.progress.close()
									self.progress = None
								sleep = 1000
								step = 6
					elif step == 6:
						if not self.player.isPlaying():
							abortReason = 'stopped'
					else:
						raise RuntimeError('Unknow step: %r' % step)
					if not abortReason:
						xbmc.sleep(sleep)
				utils.log('Player stopped: reason=%s, %s' % (abortReason, infostr()))
			finally:
				self.player.stop()
			if abortReason in ('canceled', 'stopped'):
				return True
			if step >= 4:
				raise RuntimeError('Stream died! reason=%s, %s' % (abortReason, infostr()))
			return False
		except Exception as e:
			import traceback
			utils.log(traceback.format_exc())
			return False
		return

def addDir(name, url, iconimage="DefaultFolder.png", isFolder=True, isPlayable=False):
	liz = ListItem(name)
	liz.setArt({"icon":iconimage, "thumb":iconimage})
	liz.setInfo(type="Video", infoLabels={"Title": name})
	if isPlayable:
		liz.setProperty("IsPlayable", "true")
	add(utils.handle(), url, liz, isFolder)

def addDir2(name_, icon_, action, **params):
	params['action'] = action
	addDir(name_, utils.getPluginUrl(params), getIcon(icon_))

def getIcon(name):
	return utils.py2dec(utils.translatePath('special://home/addons/' + utils.addonID + '/resources/' + name + '.png'))

def cachedcall(action, params):
	cacheKey = action + '?' + ('&').join([ str(key) + '=' + str(value) for key, value in sorted(list(params.items())) ])
	content = utils.get_cache(cacheKey)
	if content:
		utils.log("from cache")
		return content
	else:
		content = callApi2(action, params)
		utils.set_cache(cacheKey, content, timeout=1800)
		return content
	
def callApi(action, params, method='GET', headers=None, jsonreq=None):
	utils.log('callApi req: %s' % json.dumps(params))
	if not headers:
		headers = dict()
	headers['auth-token'] = utils.getAuthSignature()
	if method=='GET':
		resp = session.request(method, (BASEURL + action), params=params, headers=headers)
	else:
		resp = session.request(method, (BASEURL + action), params=params, headers=headers, json=jsonreq)
	data = resp.json()
	utils.log('callApi res: %s' % json.dumps(data))
	return data

def callApi2(action, params):
	res = callApi(action, params)
	while True:
		if type(res) is not dict or 'id' not in res or 'data' not in res:
			return res
		data = res['data']
		if type(data) is dict and data.get('type') == 'fetch':
			params = data['params']
			body = params.get('body')
			headers = params.get('headers')
			resp = session.request(params.get('method', 'GET').upper(), data['url'], headers={k:v[0] if type(v) in (list, tuple) else v for k, v in list(headers.items())} if headers else None, data=b64decode(body) if body else None, allow_redirects=params.get('redirect', 'follow') == 'follow', verify=False)
			headers = dict(resp.headers)
			resData = {'status': resp.status_code, 
			   'url': resp.url, 
			   'headers': headers, 
			   'data': b64encode(resp.content).decode("utf-8").replace('\n', '') if data['body'] else None}
			res = callApi('res', {'id': res['id']}, method='POST', jsonreq=resData)
		elif type(data) is dict and data.get('error'):
			raise ValueError(data['error'])
		else:
			return data
	return

def main():
	params = dict(utils.parse_qsl(sys.argv[2][1:]))
	if params:
		tv = params.get('name')
		action = params.pop('action', False)
		if action:
			if action == 'choose':
				import vjlive
				vjlive.choose()
			elif action == 'channels':
				import vjlive
				vjlive.channels()
			elif action == 'settings':
				utils.addon.openSettings(sys.argv[1])
			else:
				globals()[action](params)
		elif tv:
			import vjlive
			vjlive.livePlay(params['name'])
		else:
			cancel = params.get('cancel', '').lower()
			if cancel == 'home':
				xbmc.executebuiltin('ActivateWindow(Home)')
	else:
		action_index(params)