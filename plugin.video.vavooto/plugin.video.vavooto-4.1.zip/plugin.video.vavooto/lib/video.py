# -*- coding: utf-8 -*-
import xbmcplugin, sys, xbmc
from utils import *

def main():
	params = dict(parse_qsl(sys.argv[2].replace('?','')))
	action = params.get('action', '')
	tv = params.get('name', '')
	if tv and not action:
		import vjlive
		vjlive.livePlay(params['name'])
	if not action and not tv:
		action = "index"
	if action == 'home':
		xbmc.executebuiltin('ActivateWindow(Home)')
		xbmcplugin.endOfDirectory(int(sys.argv[1]))
	elif action == ('channels'):
		import vjlive
		vjlive.channels()
	elif action == 'choose':
		import vjlive
		vjlive.choose()
	else:
		if action.startswith('v2_'):
			action = action[3:]
		import vjackson2
		vjackson2.main(action, params)
			
if __name__ == '__main__':
	main()